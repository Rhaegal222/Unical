package stringhe;

import java.util.Random;

public class Main {
    private static String stampaConString() {
        String s = "";
        for(int i = 0; i < 100000; i++)
            s += i;
        return s;
    }

    //In questo caso è più veloce
    private static String stampaConStringBuilder() {
        StringBuilder s = new StringBuilder();
        for(int i = 0; i < 100000; i++)
            s.append(i);
        return s.toString();
    }
    
    final public static int value = 20000;

    //In questo caso è più veloce
    private static void testConString(int n) {
        for (int i = 0; i < value; i++)
            for (int j = 0; j < value; j++) {
                String str = "Prova " + i + " " + j;
                if(i == j && i == n) { System.out.println(str); }
            }
    }

    private static void testConStringBuilder(int n) {
        for (int i = 0; i < value; i++)
            for (int j = 0; j < value; j++) {
                StringBuilder s = new StringBuilder();
                s.append("Prova "); s.append(i); s.append(" "); s.append(j);
                String str = s.toString();
                if(i == j && i == n) { System.out.println(str); }
            }
    }

    
    public static void test() {
        long startTime = System.nanoTime();
        stampaConString();
        long stopTime = System.nanoTime();
        double duration = (double) (stopTime - startTime) / 1000000000;
        System.out.println("Durata primo metodo: " + duration + " secondi");
        startTime = System.nanoTime();
        stampaConStringBuilder();
        stopTime = System.nanoTime();
        duration = (double) (stopTime - startTime) / 1000000000;
        System.out.println("Durata secondo metodo: " + duration + " secondi");
    }

    public static void test2() {
        Random random = new Random();
        int v = random.nextInt(value);
        long startTime = System.nanoTime();
        testConString(v);
        long stopTime = System.nanoTime();
        double duration = (double) (stopTime - startTime) / 1000000000;
        System.out.println("Durata primo metodo: " + duration + " secondi");
        startTime = System.nanoTime();
        testConStringBuilder(v);
        stopTime = System.nanoTime();
        duration = (double) (stopTime - startTime) / 1000000000;
        System.out.println("Durata secondo metodo: " + duration + " secondi");
    }

    public static void main(String[] args) {
        test();
        test2();
    }
}

