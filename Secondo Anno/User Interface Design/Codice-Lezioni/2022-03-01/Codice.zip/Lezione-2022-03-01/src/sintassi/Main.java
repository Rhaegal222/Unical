package sintassi;

public class Main {
    public static void main(String[] args) {
        var a = 1; //il tipo di a è inferito automaticamente
        int[] array = new int[10];
        for(int i = 0; i < array.length; i++)
array[i] = i;
  
  
  switch(array[0]) {
            case 0 -> System.out.println("Contiene " + 0);
            case 1 -> System.out.println("Contiene " + 1);
            default -> System.out.println("Contiene altri valori");
        }

  //Possiamo fare in modo che lo switch restituisca qualcosa
  //res conterrà 0 se array[0] è 0
  //res conterrà 1 se array[0] è 1
        var res = switch(array[0]) {
            case 0 -> { System.out.println(0); yield 0; }
            case 1 -> { System.out.println(1); yield 1; }
            default -> { yield "Numero non supportato"; }
        };
  //res è dichiarato come var, quindi il tipo è inferito
  //sarà int nel caso di 0 e 1 o una stringa negli altri casi
    }
}
