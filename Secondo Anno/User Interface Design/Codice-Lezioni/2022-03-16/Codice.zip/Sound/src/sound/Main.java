package sound;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {
	
	public static void main(String[] args) {
		JFrame f = new JFrame("Sound");
		f.setSize(600,100);
		JPanel p = new JPanel();
		JButton start = new JButton("start");
		JButton stop = new JButton("pause");
		JButton restart = new JButton("restart");
		JButton loop = new JButton("loop");
		JButton incrementVolume = new JButton("+");
		JButton reduceVolume = new JButton("-");
		p.add(start);
		p.add(stop);
		p.add(restart);
		p.add(loop);
		p.add(incrementVolume);
		p.add(reduceVolume);
		f.add(p);
		Sound s = new Sound("test.wav");
		start.addActionListener(e -> s.play());
		stop.addActionListener(e -> s.pause());
		restart.addActionListener(e -> s.restart());			
		loop.addActionListener(e -> s.loop());			
		incrementVolume.addActionListener(e -> s.incrementVolume());
		reduceVolume.addActionListener(e -> s.reduceVolume());
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);								    
	}
}
