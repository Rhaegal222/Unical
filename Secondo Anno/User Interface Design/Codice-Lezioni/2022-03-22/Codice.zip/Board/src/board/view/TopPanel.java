package board.view;

import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JPanel;

import board.controller.TopPanelController;

public class TopPanel extends JPanel {

	private static final long serialVersionUID = 8039202002735442212L;

	private TopButton backgroundButton = new TopButton("Change background", TopButton.BACKGROUND);
	private TopButton colorButton = new TopButton("Change color", TopButton.COLOR);
	private TopButton cleanButton = new TopButton("Clean", TopButton.CLEAN);
	private TopButton undoButton = new TopButton("Undo", TopButton.UNDO);

	public TopPanel() {
		setPreferredSize(new Dimension(600, 40));
		this.setLayout(new GridLayout(1, 4));
		this.add(backgroundButton);
		this.add(colorButton);
		this.add(cleanButton);
		this.add(undoButton);		
	}

	public void setController(TopPanelController topController) {
		backgroundButton.addActionListener(topController);
		colorButton.addActionListener(topController);
		cleanButton.addActionListener(topController);
		undoButton.addActionListener(topController);
	}	
}
