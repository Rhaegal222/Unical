package board.model;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public record BoardData (List<BoardPointColor> points, BoardColor currentColor, File backgroundImage) {

	public BoardData(BoardData element) {
		this(new ArrayList<>(element.points), element.currentColor, element.backgroundImage);
	}
}
