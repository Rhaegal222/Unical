package board.controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;

import board.model.Board;
import board.model.BoardColor;
import board.view.BoardPanel;
import board.view.TopButton;

public class TopPanelController implements ActionListener {

	private BoardPanel panel;
	public TopPanelController(BoardPanel panel) {
		this.panel = panel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() instanceof TopButton) {
			TopButton topButton = (TopButton) e.getSource();
			switch(topButton.getType()) {
			case TopButton.BACKGROUND -> handleChangeBackground();
			case TopButton.COLOR -> { 
				int rgb = Board.getInstance().getCurrentColor().rgb();
				Color c = JColorChooser.showDialog(null, "Choose a new color", new Color(rgb));
				Board.getInstance().setCurrentColor(new BoardColor(c.getRGB()));
			}
			case TopButton.CLEAN -> { Board.getInstance().clean(); panel.repaint(); }
			case TopButton.UNDO -> { Board.getInstance().undo(); panel.repaint(); }		
			}
		}
	}
	
	private void handleChangeBackground() {		
		FileFilter imageFilter = new FileNameExtensionFilter("Image files", ImageIO.getReaderFileSuffixes());
		JFileChooser f = new JFileChooser();
		f.setFileFilter(imageFilter);
		int res = f.showOpenDialog(null);
		if (res == JFileChooser.APPROVE_OPTION) {
			File file = f.getSelectedFile();
			if(file != null) {
				Board.getInstance().setBackgroundImage(file);
				panel.repaint();
			}
		}
	}
}
