package board;

public class Settings {
	public static int WIDTH = 800;
    public static int HEIGHT = 600;
}
