package board.controller;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import board.model.Board;
import board.view.BoardPanel;

public class BoardController extends MouseAdapter {	
	
	private BoardPanel panel;
	
	public BoardController(BoardPanel panel) {
		this.panel = panel;
	}
	
	private void handleMouseEvent(MouseEvent e) {
		Board.getInstance().add(e.getX(), e.getY());
		panel.repaint();		
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		Board.getInstance().startDraw();
		handleMouseEvent(e);
	}	

	@Override
	public void mouseDragged(MouseEvent e) {
		handleMouseEvent(e);		
	}
}
