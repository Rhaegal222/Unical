package board.model;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class Board {

	private BoardData data = new BoardData(new ArrayList<>(), new BoardColor(0), null);	
	private Stack<BoardData> history = new Stack<>();
	
	private static Board instance = new Board();
	private Board() {		
	}
	
	public static Board getInstance() {
		return instance;
	}
	
	public void startDraw() {
		history.push(new BoardData(data));
	}
	
	public void add(int x, int y) {
		data.points().add(new BoardPointColor(x, y, data.currentColor()));
	}
	
	public void undo() {
		if(history.isEmpty())
			return;
		data = history.pop();		
	}
	
	public void clean() {
		history.push(new BoardData(data));
		data = new BoardData(new ArrayList<>(), data.currentColor(), null);
	}
	
	public List<BoardPointColor> getPoints() {
		return Collections.unmodifiableList(data.points());
	}
	
	public File getBackgroundImage() {
		return data.backgroundImage();
	}
	
	public BoardColor getCurrentColor() {
		return data.currentColor();
	}
	
	public void setBackgroundImage(File backgroundImage) {
		history.push(new BoardData(data));
		data = new BoardData(data.points(), data.currentColor(), backgroundImage);	
	}
	
	public void setCurrentColor(BoardColor color) {
		history.push(new BoardData(data));
		data = new BoardData(data.points(), color, data.backgroundImage());
	}
}
