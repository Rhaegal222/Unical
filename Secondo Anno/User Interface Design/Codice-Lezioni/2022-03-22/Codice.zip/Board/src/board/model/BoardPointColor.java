package board.model;

public record BoardPointColor(int x, int y, BoardColor color){
}
