package board;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JFrame;

import board.controller.BoardController;
import board.controller.TopPanelController;
import board.view.BoardPanel;
import board.view.TopPanel;

public class Main {

	public static void main(String[] args) {
		JFrame f = new JFrame("Board"); //Creazione della finestra con il titolo
		f.setSize(Settings.WIDTH, Settings.HEIGHT); //Inseriamo la dimensione della finestra
		BoardPanel board = new BoardPanel(); //Creiamo il pannello con la lavagna		
		TopPanel top = new TopPanel(); //Creiamo il pannello con gli strumenti		
		BoardController controller = new BoardController(board); //Creaiamo la classe che si occupa degli eventi
		TopPanelController topController = new TopPanelController(board);		
		top.setController(topController);
		board.setController(controller);
		
		f.add(top, BorderLayout.NORTH); //Gli strumenti vanno nella parte superiore del BorderLayout
		f.add(board, BorderLayout.CENTER); //La lavagna va nella parte centrale del BorderLayout 
		
		//Gestiamo l'evento di ridimensionamento della finestra
		f.addComponentListener(new ComponentAdapter() {			
			@Override
			public void componentResized(ComponentEvent e) {
				board.componentResized();
			}
		});
		
		//Settiamo la dimensione minima
		f.setMinimumSize(new Dimension(Settings.WIDTH, Settings.HEIGHT));
		
		//Rendiamo il frame visibile
		f.setVisible(true);
		
		//Alla pressione del pulsante di chiusura, l'applicazione termina
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
	}
}
