package board.model;

public record BoardColor(int rgb) {

}
