package board.view;

import javax.swing.JButton;

public class TopButton extends JButton {

	private static final long serialVersionUID = -826302323379927706L;
	
	public static final int BACKGROUND = 0;
	public static final int COLOR = 1;
	public static final int CLEAN = 2;
	public static final int UNDO = 3;
	
	private int type;
	public TopButton(String text, int type) {
		super(text);
		this.type = type;		
	}
	
	public int getType() {
		return type;
	}
}
