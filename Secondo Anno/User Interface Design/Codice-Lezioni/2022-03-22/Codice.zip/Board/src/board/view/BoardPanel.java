package board.view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import board.controller.BoardController;
import board.model.Board;
import board.model.BoardPointColor;

public class BoardPanel extends JPanel {
	
	private static final long serialVersionUID = 5379358483855227909L;
	private Image background = null;
	private File backgroundFile = Board.getInstance().getBackgroundImage();
	
	public BoardPanel() {
		setBackground(Color.WHITE);
	}	
	
	public void setController(BoardController controller) {
		addMouseListener(controller);
		addMouseMotionListener(controller);		
	}
	
	private void updateBackground() {		
		try {
			backgroundFile = Board.getInstance().getBackgroundImage();
			background = ImageIO.read(backgroundFile);
			background = background.getScaledInstance(getSize().width, getSize().height, Image.SCALE_SMOOTH);						
		} catch (Exception e) {
			background = null;
		}
	}
	
	public void componentResized() {
		updateBackground();
	}
	
	//NO paintComponent***S***
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		if(Board.getInstance().getBackgroundImage() != null) {
			if(!Board.getInstance().getBackgroundImage().equals(backgroundFile))
				updateBackground();
			g.drawImage(background, 0, 0, null);
		}
		else
			setBackground(Color.WHITE);
		for(BoardPointColor p : Board.getInstance().getPoints()) {
			g.setColor(new Color(p.color().rgb()));
			g.fillOval(p.x(), p.y(), 10, 10);
		}
	}
}
