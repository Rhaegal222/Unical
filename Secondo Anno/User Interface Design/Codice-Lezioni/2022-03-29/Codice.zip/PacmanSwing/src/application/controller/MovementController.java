package application.controller;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import application.Settings;
import application.model.Game;
import application.view.PacmanGraphics;

public class MovementController extends KeyAdapter {

	private PacmanGraphics pacmanGraphics;

	public MovementController(PacmanGraphics pacmanGraphics) {		
		this.pacmanGraphics = pacmanGraphics;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
			System.exit(0);
		
		int direction = switch (e.getKeyCode()) {
			case KeyEvent.VK_LEFT -> Settings.MOVE_LEFT;
			case KeyEvent.VK_RIGHT -> Settings.MOVE_RIGHT;
			case KeyEvent.VK_DOWN-> Settings.MOVE_DOWN;
			case KeyEvent.VK_UP -> Settings.MOVE_UP;			
			default -> Settings.NO_OP;
		};		
		if(direction == Settings.NO_OP)
			return;
		Game.getInstance().move(direction);
		pacmanGraphics.repaint();
	}
	
}
