package application.view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import application.Settings;
import application.controller.MovementController;
import application.model.Block;
import application.model.Game;

public class PacmanGraphics extends JPanel {	
	private static final long serialVersionUID = 6865224444652474855L;
	
	private Image[] images = new Image[4];
	private final String PATH = "/application/resources/";

	public PacmanGraphics() {
		setBackground(Color.BLACK);
		try {
			images[Settings.MOVE_RIGHT] = ImageIO.read(getClass().getResourceAsStream(PATH + "pacman_right.png"));
			images[Settings.MOVE_LEFT] = ImageIO.read(getClass().getResourceAsStream(PATH + "pacman_left.png"));
			images[Settings.MOVE_UP] = ImageIO.read(getClass().getResourceAsStream(PATH + "pacman_up.png"));
			images[Settings.MOVE_DOWN] = ImageIO.read(getClass().getResourceAsStream(PATH + "pacman_down.png"));
			for(int i = 0; i < images.length; i++) {
				images[i] = images[i].getScaledInstance(Settings.BLOCK_SIZE_IN_PIXEL, Settings.BLOCK_SIZE_IN_PIXEL, Image.SCALE_SMOOTH);
			}
		} catch(IOException e) {				
		}
	}
	
	public void setController(MovementController controller) {
		addKeyListener(controller);	
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		var game = Game.getInstance();
		for(int i = 0; i < game.getBlocks().length; i++) {
			int x = Settings.BLOCK_SIZE_IN_PIXEL * i;
			for(int j = 0; j < game.getBlocks()[i].length; j++) {
				int y = Settings.BLOCK_SIZE_IN_PIXEL * j;
				switch(game.getBlocks()[i][j].type()) {
				case Block.PACMAN -> g.drawImage(images[game.getCurrentDirection()], x, y, Settings.BLOCK_SIZE_IN_PIXEL, Settings.BLOCK_SIZE_IN_PIXEL, null);				
				case Block.WALL -> { g.setColor(Color.BLUE); g.fillRect(x, y, Settings.BLOCK_SIZE_IN_PIXEL, Settings.BLOCK_SIZE_IN_PIXEL); }
				case Block.POINT -> { g.setColor(Color.YELLOW); g.fillOval(x + Settings.BLOCK_SIZE_IN_PIXEL/4, y + Settings.BLOCK_SIZE_IN_PIXEL/4, Settings.BLOCK_SIZE_IN_PIXEL/2, Settings.BLOCK_SIZE_IN_PIXEL/2);}
				case Block.EMPTY -> {} 
				};
			}
		}
	}
}
