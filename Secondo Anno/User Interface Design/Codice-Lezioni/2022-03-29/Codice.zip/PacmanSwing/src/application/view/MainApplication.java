package application.view;

import javax.swing.JFrame;

import application.controller.MovementController;

public class MainApplication {

	public static void launch(String[] args) {
		JFrame f = new JFrame("Pacman");
		f.setSize(800, 800);		
		PacmanGraphics pacmanGraphics = new PacmanGraphics();
		MovementController controller = new MovementController(pacmanGraphics);
		pacmanGraphics.setController(controller);
		pacmanGraphics.setFocusable(true);
		pacmanGraphics.requestFocus();
		f.add(pacmanGraphics);
		f.setUndecorated(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);		
	}
}
