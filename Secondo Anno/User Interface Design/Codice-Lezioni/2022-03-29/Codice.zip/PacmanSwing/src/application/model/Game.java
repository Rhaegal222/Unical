package application.model;

import java.util.Random;

import application.Settings;

public class Game {

	private Block[][] blocks = new Block[Settings.CELL_SIZE][Settings.CELL_SIZE];
	private int x;
	private int y;
	private int currentDirection = Settings.MOVE_RIGHT;

	private int coins;
	
	private static Game instance = null;
	
	public static Game getInstance() {
		if(instance == null)
			instance = new Game();
		return instance;
	}

	private Game() {
		x = 0;
		y = 0;
		coins = 0;
		for (int i = 0; i < blocks.length; i++) {
			for (int j = 0; j < blocks[i].length; j++) {
				blocks[i][j] = new Block(Block.EMPTY);
			}
		}
		blocks[x][y] = new Block(Block.PACMAN);
		Random r = new Random();
		int min = 1;
		int max = 100;		
		for (int i = 0; i < blocks.length; i++) {
			for (int j = 0; j < blocks[i].length; j++) {
				int result = r.nextInt(max - min) + min;
				if (i != 0 && j != 0) {
					if (result >= 1 && result <= 10)
						blocks[i][j] = new Block(Block.WALL);
					else if (result >= 11 && result <= 50)
						blocks[i][j] = new Block(Block.POINT);
					else
						blocks[i][j] = new Block(Block.EMPTY);
				}
			}
		}
	}

	public void move(int direction) {
		if (direction != Settings.MOVE_LEFT && direction != Settings.MOVE_RIGHT && direction != Settings.MOVE_UP && direction != Settings.MOVE_DOWN)
			return;
		if (collision(newX(direction), newY(direction)))
			return;
		currentDirection = direction;
		blocks[x][y] = new Block(Block.EMPTY);
		x = newX(direction);
		y = newY(direction);
		if (blocks[x][y].type() == Block.POINT)
			coins++;
		blocks[x][y] = new Block(Block.PACMAN);		
	}

	private int newX(int direction) {
		if (direction == Settings.MOVE_RIGHT) {
			return (x + 1) % Settings.CELL_SIZE;
		} else if (direction == Settings.MOVE_LEFT) {
			if (x == 0)
				return Settings.CELL_SIZE - 1;
			return x - 1;
		}
		return x;
	}

	private int newY(int direction) {
		if (direction == Settings.MOVE_UP) {
			if (y == 0)
				return Settings.CELL_SIZE - 1;
			return y - 1;
		} else if (direction == Settings.MOVE_DOWN) {
			return (y + 1) % Settings.CELL_SIZE;
		}
		return y;
	}

	private boolean collision(int x, int y) {
		return blocks[x][y].type() == Block.WALL;
	}

	public Block[][] getBlocks() {
		return blocks;
	}
	
	public int getCoins() {
		return coins;
	}

	public int getCurrentDirection() {
		return currentDirection;
	}
}
