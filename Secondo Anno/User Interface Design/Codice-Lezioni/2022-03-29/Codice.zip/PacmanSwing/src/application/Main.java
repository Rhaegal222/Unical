package application;

import application.view.MainApplication;

public class Main {

	public static void main(String[] args) {
		MainApplication.launch(args);	
	}
}
