package main;

import java.util.Arrays;
import java.util.Comparator;

public class Prova {

	public static void main(String[] args) {
		Persona[] persone = new Persona[4];
		Persona p = new Persona("Nome", "Cognome", 50);
		persone[0] = p;
		persone[1] = new Persona("Nome2", "Cognome2", 22);
		persone[2] = new Persona("Nome3", "Cognome3", 44);
		persone[3] = new Persona("Nome4", "Cognome4", 33);
		Arrays.sort(persone); //ordinamento usando la classe Persona
		Arrays.sort(persone, new Comparator<Persona>() {
			@Override
			public int compare(Persona o1, Persona o2) {
				return o1.getEta().compareTo(o2.getEta()) * -1; //ordinamento per Comparator
			}
		});
		for(Persona p1 : persone) {
			System.out.println(p1);
		}
		
		
	}

}
